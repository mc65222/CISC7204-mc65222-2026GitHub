
import pandas as pd
import dash
from dash import html, dcc, Input, Output
import plotly.express as px

# Load wildfire dataset
url = (
    "https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/"
    "IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/"
    "Historical_Wildfires.csv"
)

df = pd.read_csv(url)

# Extract year and month
df["Date"] = pd.to_datetime(df["Date"])
df["Month"] = df["Date"].dt.month_name()
df["Year"] = df["Date"].dt.year

# Create Dash application
app = dash.Dash(__name__)

# Task 2.1 - Dashboard title
app.layout = html.Div(children=[
    html.H1(
        "Australia Wildfire Dashboard",
        style={
            "textAlign": "center",
            "color": "#503D36",
            "fontSize": 26
        }
    ),

    # Task 2.2 - Region and year selectors
    html.Div([
        html.Div([
            html.H2(
                "Select Region:",
                style={"marginRight": "2em"}
            ),

            dcc.RadioItems(
                options=[
                    {"label": "New South Wales", "value": "NSW"},
                    {"label": "Northern Territory", "value": "NT"},
                    {"label": "Queensland", "value": "QL"},
                    {"label": "South Australia", "value": "SA"},
                    {"label": "Tasmania", "value": "TA"},
                    {"label": "Victoria", "value": "VI"},
                    {"label": "Western Australia", "value": "WA"}
                ],
                value="NSW",
                id="region",
                inline=True
            )
        ]),

        html.Div([
            html.H2(
                "Select Year:",
                style={"marginRight": "2em"}
            ),

            dcc.Dropdown(
                options=[
                    {"label": str(year), "value": year}
                    for year in range(2005, 2021)
                ],
                value=2005,
                id="year",
                clearable=False,
                style={"width": "250px"}
            )
        ], style={"marginTop": "25px"}),

        # Task 2.3 - Output containers
        html.Div([
            html.Div(
                id="plot1",
                style={"width": "50%", "padding": "10px"}
            ),

            html.Div(
                id="plot2",
                style={"width": "50%", "padding": "10px"}
            )
        ], style={
            "display": "flex",
            "flexWrap": "wrap",
            "marginTop": "30px"
        })
    ])
])

# Task 2.4 - Callback
@app.callback(
    [
        Output("plot1", "children"),
        Output("plot2", "children")
    ],
    [
        Input("region", "value"),
        Input("year", "value")
    ]
)

# Task 2.5 - Generate charts
def reg_year_display(input_region, input_year):

    region_data = df[df["Region"] == input_region]

    y_r_data = region_data[
        region_data["Year"] == input_year
    ]

    # Plot 1 - Monthly average estimated fire area
    est_data = (
        y_r_data.groupby("Month")["Estimated_fire_area"]
        .mean()
        .reset_index()
    )

    fig1 = px.pie(
        est_data,
        values="Estimated_fire_area",
        names="Month",
        title=(
            f"{input_region}: Monthly Average Estimated "
            f"Fire Area in year {input_year}"
        )
    )

    # Plot 2 - Average count of pixels
    veg_data = (
        y_r_data.groupby("Month")["Count"]
        .mean()
        .reset_index()
    )

    month_order = [
        "January", "February", "March", "April",
        "May", "June", "July", "August",
        "September", "October", "November", "December"
    ]

    fig2 = px.bar(
        veg_data,
        x="Month",
        y="Count",
        title=(
            f"{input_region}: Average Count of Pixels "
            f"for Presumed Vegetation Fires in year {input_year}"
        ),
        category_orders={"Month": month_order}
    )

    fig2.update_layout(
        xaxis_title="Month",
        yaxis_title="Average Count of Pixels"
    )

    return [
        dcc.Graph(figure=fig1),
        dcc.Graph(figure=fig2)
    ]


if __name__ == "__main__":
    app.run(debug=True, port=8050)

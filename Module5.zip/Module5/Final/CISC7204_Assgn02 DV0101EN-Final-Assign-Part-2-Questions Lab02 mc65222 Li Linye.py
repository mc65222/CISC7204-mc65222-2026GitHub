
import pandas as pd
import dash
from dash import html, dcc, Input, Output
import plotly.express as px

# =====================================================
# Load dataset
# =====================================================

DATA_URL = (
    "https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/"
    "IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/"
    "historical_automobile_sales.csv"
)

data = pd.read_csv(DATA_URL)

# Ensure year and month columns are available
data["Date"] = pd.to_datetime(data["Date"])

data["Year"] = data["Date"].dt.year
data["Month"] = data["Date"].dt.month

# =====================================================
# Create Dash Application
# =====================================================

app = dash.Dash(__name__)

# Task 2.1 - Set dashboard title
app.title = "Automobile Sales Statistics Dashboard"

# Teacher's year selection range
year_list = list(range(1980, 2024))

# =====================================================
# Task 2.2 and Task 2.3 - Application Layout
# =====================================================

app.layout = html.Div(children=[

    html.H1(
        "Automobile Sales Statistics Dashboard",
        style={
            "textAlign": "center",
            "color": "#503D36",
            "fontSize": 24
        }
    ),

    # Report type dropdown
    html.Div([
        html.Label(
            "Select Statistics:",
            style={"fontWeight": "bold"}
        ),

        dcc.Dropdown(
            id="dropdown-statistics",
            options=[
                {
                    "label": "Yearly Statistics",
                    "value": "Yearly Statistics"
                },
                {
                    "label": "Recession Period Statistics",
                    "value": "Recession Period Statistics"
                }
            ],
            value="Yearly Statistics",
            clearable=False
        )
    ], style={
        "width": "48%",
        "display": "inline-block",
        "padding": "10px"
    }),

    # Year dropdown
    html.Div([
        html.Label(
            "Select Year:",
            style={"fontWeight": "bold"}
        ),

        dcc.Dropdown(
            id="select-year",
            options=[
                {"label": str(i), "value": i}
                for i in year_list
            ],
            value=1980,
            clearable=False
        )
    ], style={
        "width": "48%",
        "display": "inline-block",
        "padding": "10px"
    }),

    # Output display
    html.Div(
        id="output-container",
        className="chart-grid",
        style={
            "display": "grid",
            "gridTemplateColumns": "repeat(2, minmax(0, 1fr))",
            "gap": "15px",
            "padding": "15px"
        }
    )
])

# =====================================================
# Task 2.4 - Callback 1
# Enable or disable year selection
# =====================================================

@app.callback(
    Output("select-year", "disabled"),
    Input("dropdown-statistics", "value")
)
def update_input_container(selected_statistics):

    if selected_statistics == "Yearly Statistics":
        return False

    return True


# =====================================================
# Task 2.4 - Callback 2
# Update Dashboard Charts
# =====================================================

@app.callback(
    Output("output-container", "children"),
    [
        Input("dropdown-statistics", "value"),
        Input("select-year", "value")
    ]
)
def update_output_container(selected_statistics, input_year):

    # =================================================
    # Task 2.5 - Recession Period Statistics
    # =================================================

    if selected_statistics == "Recession Period Statistics":

        recession_data = data[data["Recession"] == 1]

        # ---------------------------------------------
        # R1: Average automobile sales by recession year
        # ---------------------------------------------

        yearly_rec = (
            recession_data.groupby("Year")["Automobile_Sales"]
            .mean()
            .reset_index()
        )

        R_chart1 = dcc.Graph(
            figure=px.line(
                yearly_rec,
                x="Year",
                y="Automobile_Sales",
                markers=True,
                title="Average Automobile Sales During Recession"
            )
        )

        # ---------------------------------------------
        # R2: Average sales by vehicle type
        # ---------------------------------------------

        average_sales = (
            recession_data.groupby("Vehicle_Type")["Automobile_Sales"]
            .mean()
            .reset_index()
        )

        R_chart2 = dcc.Graph(
            figure=px.bar(
                average_sales,
                x="Vehicle_Type",
                y="Automobile_Sales",
                color="Vehicle_Type",
                title="Average Vehicles Sold by Vehicle Type During Recession"
            )
        )

        # ---------------------------------------------
        # R3: Advertising expenditure by vehicle type
        # ---------------------------------------------

        exp_rec = (
            recession_data.groupby("Vehicle_Type")["Advertising_Expenditure"]
            .sum()
            .reset_index()
        )

        R_chart3 = dcc.Graph(
            figure=px.pie(
                exp_rec,
                values="Advertising_Expenditure",
                names="Vehicle_Type",
                title="Total Advertising Expenditure Share by Vehicle Type During Recession"
            )
        )

        # ---------------------------------------------
        # R4: Unemployment rate and automobile sales
        # ---------------------------------------------

        unemp_data = (
            recession_data.groupby(
                ["unemployment_rate", "Vehicle_Type"]
            )["Automobile_Sales"]
            .mean()
            .reset_index()
        )

        R_chart4 = dcc.Graph(
            figure=px.bar(
                unemp_data,
                x="unemployment_rate",
                y="Automobile_Sales",
                color="Vehicle_Type",
                barmode="group",
                labels={
                    "unemployment_rate": "Unemployment Rate",
                    "Automobile_Sales": "Average Automobile Sales"
                },
                title="Effect of Unemployment Rate on Vehicle Type and Sales"
            )
        )

        return [
            html.Div(
                R_chart1,
                className="chart-item",
                style={"minWidth": 0}
            ),
            html.Div(
                R_chart2,
                className="chart-item",
                style={"minWidth": 0}
            ),
            html.Div(
                R_chart3,
                className="chart-item",
                style={"minWidth": 0}
            ),
            html.Div(
                R_chart4,
                className="chart-item",
                style={"minWidth": 0}
            )
        ]

    # =================================================
    # Task 2.6 - Yearly Automobile Sales Statistics
    # =================================================

    elif selected_statistics == "Yearly Statistics":

        if input_year is None:
            return html.Div("Please select a year.")

        yearly_data = data[data["Year"] == input_year]

        # ---------------------------------------------
        # Y1: Yearly automobile sales for whole period
        # ---------------------------------------------

        yas = (
            data.groupby("Year")["Automobile_Sales"]
            .mean()
            .reset_index()
        )

        Y_chart1 = dcc.Graph(
            figure=px.line(
                yas,
                x="Year",
                y="Automobile_Sales",
                markers=True,
                title="Yearly Average Automobile Sales"
            )
        )

        # ---------------------------------------------
        # Y2: Total monthly automobile sales
        # ---------------------------------------------

        mas = (
            yearly_data.groupby("Month")["Automobile_Sales"]
            .sum()
            .reset_index()
        )

        Y_chart2 = dcc.Graph(
            figure=px.line(
                mas,
                x="Month",
                y="Automobile_Sales",
                markers=True,
                title=(
                    f"Total Monthly Automobile Sales in {input_year}"
                )
            )
        )

        # ---------------------------------------------
        # Y3: Average sales by vehicle type
        # ---------------------------------------------

        avr_vdata = (
            yearly_data.groupby("Vehicle_Type")["Automobile_Sales"]
            .mean()
            .reset_index()
        )

        Y_chart3 = dcc.Graph(
            figure=px.bar(
                avr_vdata,
                x="Vehicle_Type",
                y="Automobile_Sales",
                color="Vehicle_Type",
                title=(
                    f"Average Vehicles Sold by Vehicle Type in {input_year}"
                )
            )
        )

        # ---------------------------------------------
        # Y4: Advertising expenditure by vehicle type
        # ---------------------------------------------

        exp_data = (
            yearly_data.groupby("Vehicle_Type")["Advertising_Expenditure"]
            .sum()
            .reset_index()
        )

        Y_chart4 = dcc.Graph(
            figure=px.pie(
                exp_data,
                values="Advertising_Expenditure",
                names="Vehicle_Type",
                title=(
                    f"Total Advertising Expenditure by Vehicle Type in {input_year}"
                )
            )
        )

        return [
            html.Div(
                Y_chart1,
                className="chart-item",
                style={"minWidth": 0}
            ),
            html.Div(
                Y_chart2,
                className="chart-item",
                style={"minWidth": 0}
            ),
            html.Div(
                Y_chart3,
                className="chart-item",
                style={"minWidth": 0}
            ),
            html.Div(
                Y_chart4,
                className="chart-item",
                style={"minWidth": 0}
            )
        ]

    return html.Div("Please select a report type.")


# =====================================================
# Run Application
# =====================================================

if __name__ == "__main__":
    app.run(debug=True, port=8050)
